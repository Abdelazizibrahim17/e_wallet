import java.util.ArrayList;
import java.util.List;

public class EWalletSystem {

    List<Account> accounts;

    public EWalletSystem() {
        accounts = new ArrayList<>();

        // Auto-create admin
        accounts.add(new Account("IAM", "IAM123", "01000000000", 30, true));
    }
    public void signup(String username, String password, String phone, int age) throws Exception {

        // Username validation
        if (username.length() < 3)
            throw new Exception("Username must be at least 3 characters");

        if (!Character.isUpperCase(username.charAt(0)))
            throw new Exception("Username must start with uppercase letter");

        // Password validation
        if (password.length() < 6)
            throw new Exception("Password must be at least 6 characters");

        if (!password.matches(".*[A-Z].*") || !password.matches(".*\\d.*"))
            throw new Exception("Password must contain uppercase letter and number");

        // Age validation
        if (age < 18)
            throw new Exception("Age must be 18 or older");

        // Phone validation (Egypt)
        if (!phone.matches("^01[0-2,5]{1}[0-9]{8}$"))
            throw new Exception("Invalid Egyptian phone number");

        // Duplicate checks
        for (Account acc : accounts) {
            if (acc.username.equals(username))
                throw new Exception("Username already exists");

            if (acc.phone.equals(phone))
                throw new Exception("Phone already exists");
        }

        // Create account
        Account newAcc = new Account(username, password, phone, age, false);
        accounts.add(newAcc);

        System.out.println("Account created successfully!");
    }
    public Account login(String username, String password) throws Exception {

        if (username.isEmpty() || password.isEmpty())
            throw new Exception("Username and password cannot be empty");

        for (Account acc : accounts) {
            if (acc.username.equals(username)) {

                if (!acc.isActive)
                    throw new Exception("Account is inactive");

                if (acc.password.equals(password)) {
                    return acc;
                } else {
                    throw new Exception("Incorrect password");
                }
            }
        }

        throw new Exception("User not found");
    }
    public void showMenu(Account user) {
        System.out.println("\nWelcome, " + user.username);

        System.out.println("1. Deposit");
        System.out.println("2. Withdraw");
        System.out.println("3. Transfer");
        System.out.println("4. Show Details");
        System.out.println("5. Change Password");
        System.out.println("6. Logout");
    }
    public void deposit(Account user, double amount) throws Exception {

        if (amount <= 0)
            throw new Exception("Amount must be greater than 0");

        if (!user.isActive)
            throw new Exception("Account is inactive");

        user.balance += amount;

        System.out.println("Deposit successful. New balance: " + user.balance);
    }
    public void withdraw(Account user, double amount) throws Exception {

        if (amount <= 0)
            throw new Exception("Amount must be greater than 0");

        if (!user.isActive)
            throw new Exception("Account is inactive");

        if (amount > user.balance)
            throw new Exception("Insufficient balance");

        user.balance -= amount;

        System.out.println("Withdraw successful. New balance: " + user.balance);
    }
    public void transfer(Account sender, String receiverUsername, double amount) throws Exception {

        if (amount <= 0)
            throw new Exception("Amount must be greater than 0");

        if (!sender.isActive)
            throw new Exception("Your account is inactive");

        Account receiver = null;

        // find receiver
        for (Account acc : accounts) {
            if (acc.username.equals(receiverUsername)) {
                receiver = acc;
                break;
            }
        }

        if (receiver == null)
            throw new Exception("Receiver not found");

        if (!receiver.isActive)
            throw new Exception("Receiver account is inactive");

        if (sender.username.equals(receiver.username))
            throw new Exception("Cannot transfer to yourself");

        if (amount > sender.balance)
            throw new Exception("Insufficient balance");

        // perform transfer
        sender.balance -= amount;
        receiver.balance += amount;

        System.out.println("Transfer successful!");
        System.out.println("Your balance: " + sender.balance);
    }
    public void showDetails(Account user) {

        System.out.println("\n--- Account Details ---");
        System.out.println("Username: " + user.username);
        System.out.println("Phone: " + user.phone);
        System.out.println("Age: " + user.age);
        System.out.println("Balance: " + user.balance);

        // Optional masking
        System.out.println("Password: ******");
    }
    public void changePassword(Account user, String oldPass, String newPass) throws Exception {

        if (!user.password.equals(oldPass))
            throw new Exception("Old password is incorrect");

        if (newPass.length() < 6)
            throw new Exception("Password must be at least 6 characters");

        if (!newPass.matches(".*[A-Z].*") || !newPass.matches(".*\\d.*"))
            throw new Exception("Password must contain uppercase letter and number");

        if (newPass.equals(oldPass))
            throw new Exception("Cannot reuse old password");

        user.password = newPass;

        System.out.println("Password updated successfully!");
    }


}