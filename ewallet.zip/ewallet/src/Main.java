import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        EWalletSystem system = new EWalletSystem();
        Scanner scanner = new Scanner(System.in);

        try {
            system.signup("Abdelaziz", "Pass123", "01023456789", 22);
        } catch (Exception e) {}

        Account loggedInUser = null;
        int attempts = 0;

        // LOGIN
        while (attempts < 3) {
            try {
                System.out.print("Username: ");
                String u = scanner.nextLine();

                System.out.print("Password: ");
                String p = scanner.nextLine();

                loggedInUser = system.login(u, p);
                break;

            } catch (Exception e) {
                System.out.println(e.getMessage());
                attempts++;
            }
        }

        if (loggedInUser == null) {
            System.out.println("Login failed.");
            return;
        }

        // MENU LOOP
        while (true) {
            system.showMenu(loggedInUser);

            System.out.print("Choose: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    try {
                        System.out.print("Enter amount: ");
                        double amount = scanner.nextDouble();
                        scanner.nextLine();

                        system.deposit(loggedInUser, amount);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 2:
                    try {
                        System.out.print("Enter amount: ");
                        double amount = scanner.nextDouble();
                        scanner.nextLine();

                        system.withdraw(loggedInUser, amount);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    try {
                        System.out.print("Enter receiver username: ");
                        String receiver = scanner.nextLine();

                        System.out.print("Enter amount: ");
                        double amount = scanner.nextDouble();
                        scanner.nextLine();

                        system.transfer(loggedInUser, receiver, amount);

                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    system.showDetails(loggedInUser);
                    break;
                case 5:
                    try {
                        System.out.print("Enter old password: ");
                        String oldPass = scanner.nextLine();

                        System.out.print("Enter new password: ");
                        String newPass = scanner.nextLine();

                        system.changePassword(loggedInUser, oldPass, newPass);

                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 6:
                    System.out.println("Logged out.");
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}