public class Account {
    String username;
    String password;
    String phone;
    int age;
    double balance;
    boolean isAdmin;
    boolean isActive;

    public Account(String username, String password, String phone, int age, boolean isAdmin) {
        this.username = username;
        this.password = password;
        this.phone = phone;
        this.age = age;
        this.balance = 0.0;
        this.isAdmin = isAdmin;
        this.isActive = true;
    }
}
